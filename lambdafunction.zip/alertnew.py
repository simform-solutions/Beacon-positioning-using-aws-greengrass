import sys
import greengrasssdk
import platform
import os
import RPi.GPIO as GPIO
import logging
import time

GPIO.setmode(GPIO.BOARD) ## Use board pin numbering
GPIO.setup(7, GPIO.OUT) ## Setup GPIO Pin 7 to OUT
# Create a Greengrass Core SDK client.
client = greengrasssdk.client('iot-data')
devicePath = '/home/pi/blinking/blinking.py'

def function_handler(event, context):
    client.publish(topic='hello/world/position', payload='Sent from AWS Greengrass Core.')
    try:
        deviceInfo = os.stat(devicePath)
        GPIO.setwarnings(False)
        GPIO.output(7,GPIO.HIGH)
        time.sleep(3)
        GPIO.output(7,GPIO.LOW)
        time.sleep(3)
    except Exception as e:
        logging.error("Experiencing error :{}".format(e))
    return